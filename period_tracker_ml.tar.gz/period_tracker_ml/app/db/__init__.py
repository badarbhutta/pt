# app/db/__init__.py
"""Database module for Period Tracker ML application."""