# app/api/__init__.py
"""API module for Period Tracker ML application."""