# app/api/api_v1/endpoints/__init__.py
"""API endpoints for Period Tracker ML application."""