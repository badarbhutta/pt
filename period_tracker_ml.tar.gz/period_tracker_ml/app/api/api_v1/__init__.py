# app/api/api_v1/__init__.py
"""API v1 module for Period Tracker ML application."""