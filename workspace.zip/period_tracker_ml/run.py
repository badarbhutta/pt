import uvicorn
import os
import sys
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

# Make sure all modules are importable
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    
    # Initialize database if running in development mode
    if os.getenv("ENV", "development") == "development":
        from app.db.session import init_db
        print("Initializing database...")
        init_db()
    
    # Run the FastAPI application
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=port,
        reload=True if os.getenv("ENV", "development") == "development" else False,
        workers=int(os.getenv("WORKERS", 1))
    )
    
    print(f"Period Tracker ML API running on http://localhost:{port}")