# Period Tracker ML API

This repository contains the machine learning components for a period tracker application, implemented using FastAPI.

## Overview

The Period Tracker ML API provides:

1. **Prediction endpoints** for menstrual cycles, fertility windows, and ovulation dates
2. **Model training** capabilities that improve with user data
3. **Continuous learning** from user feedback
4. **Personalized predictions** based on individual cycle patterns

## Getting Started

### Prerequisites

- Python 3.9+
- pip package manager

### Installation

1. Clone the repository:
   

2. Create a virtual environment:
   

3. Install dependencies:
   

### Running the API

Start the API server with:



The API will be available at `http://localhost:8000`.

API documentation (Swagger UI) will be available at `http://localhost:8000/docs`.

## API Endpoints

### Prediction Endpoints

- `/api/v1/predictions/period` - Predict next period dates
- `/api/v1/predictions/fertility` - Predict fertility window
- `/api/v1/predictions/ovulation` - Predict ovulation day
- `/api/v1/predictions/confidence` - Get prediction confidence scores
- `/api/v1/predictions/history` - Get historical predictions
- `/api/v1/predictions/accuracy` - Get prediction accuracy statistics

### Model Training Endpoints

- `/api/v1/training/trigger` - Trigger model training
- `/api/v1/training/status/{training_id}` - Check training status
- `/api/v1/training/models` - List available ML models
- `/api/v1/training/models/{model_id}` - Get model details
- `/api/v1/training/models/{model_id}/metrics` - Get model metrics
- `/api/v1/training/models/{model_id}/activate` - Activate a model
- `/api/v1/training/feature-importance/{model_id}` - Get feature importance

## Architecture

The ML component uses an ensemble approach combining:

1. **ARIMA models** - For time series prediction of cycle lengths
2. **Random Forest** - For symptom-based adjustments
3. **Gradient Boosting** - For fertility window and ovulation predictions

## Integration with Laravel Backend

The ML API is designed to work with a Laravel backend that handles user data storage, authentication, and the main application features. Communication happens via API calls, with the Laravel backend acting as a client to this ML service.

## License

This project is licensed under the MIT License - see the LICENSE file for details.