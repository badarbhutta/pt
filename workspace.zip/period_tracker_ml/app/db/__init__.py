"""
Database initialization module for the period tracker ML API.
"""
from app.db.session import engine, SessionLocal
from app.db.base_class import Base