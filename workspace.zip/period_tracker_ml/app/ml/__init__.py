"""
Initialization module for the Machine Learning components of the period tracker app.
"""

# Import core ML components for easy access
from app.ml.models import (
    ARIMAModel,
    RandomForestModel, 
    GradientBoostingModel, 
    EnsembleIntegrator,
    PredictionService
)

from app.ml.preprocessing import DataProcessor
from app.ml.training import TrainingService
from app.ml.evaluation import ModelEvaluator

# Initialize the models directory
import os
os.makedirs("models", exist_ok=True)

# Version
__version__ = "0.1.0"

# Package metadata
__author__ = "Period Tracker ML Team"
__description__ = "Machine learning components for period prediction and analysis"