import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Union, Optional
from datetime import datetime, timedelta

class DataProcessor:
    """Handles preprocessing of user data for ML model training and prediction."""
    
    def __init__(self):
        self.feature_columns = []
        self.categorical_features = ['cervical_fluid', 'ovulation_test']
        self.numeric_features = ['basal_temp', 'weight', 'sleep_hours', 'exercise_minutes', 'stress_level']
        self.binary_symptoms = ['cramps', 'headache', 'bloating', 'mood_swings', 'fatigue', 'acne', 
                              'breast_tenderness', 'backache', 'nausea', 'spotting']
        
    def preprocess_user_data(self, user_data: Dict) -> Dict:
        """
        Prepare user data for prediction.
        
        Args:
            user_data: Raw user data including cycle, symptoms and biometric information
            
        Returns:
            Dictionary with processed features ready for model input
        """
        features = {}
        
        # Extract cycle information
        features['user_id'] = user_data.get('user_id')
        
        # Process cycle data
        cycle_lengths = user_data.get('cycle_lengths', [])
        if cycle_lengths:
            features['avg_cycle_length'] = np.mean(cycle_lengths)
            features['min_cycle_length'] = np.min(cycle_lengths)
            features['max_cycle_length'] = np.max(cycle_lengths)
            features['cycle_variance'] = np.var(cycle_lengths) if len(cycle_lengths) > 1 else 0
            
            # Calculate cycle regularity score (lower variance = higher regularity)
            max_expected_variance = 25  # Arbitrary threshold for normalization
            features['cycle_regularity'] = max(0, 1 - (features['cycle_variance'] / max_expected_variance))
        else:
            # Default values if no cycle data is available
            features['avg_cycle_length'] = 28
            features['min_cycle_length'] = 28
            features['max_cycle_length'] = 28
            features['cycle_variance'] = 0
            features['cycle_regularity'] = 1
        
        # Process current cycle information
        last_period_start = user_data.get('last_period_start')
        if last_period_start:
            if isinstance(last_period_start, str):
                last_period_start = datetime.fromisoformat(last_period_start)
            
            features['days_since_last_period'] = (datetime.now() - last_period_start).days
            features['current_cycle_day'] = features['days_since_last_period'] + 1
        else:
            features['days_since_last_period'] = 0
            features['current_cycle_day'] = 1
        
        # Process binary symptoms (present/absent)
        symptoms = user_data.get('symptoms', {})
        for symptom in self.binary_symptoms:
            features[f'symptom_{symptom}'] = int(symptoms.get(symptom, False))
        
        # Process biometrics
        biometrics = user_data.get('biometrics', {})
        for feature in self.numeric_features:
            if feature in biometrics:
                features[feature] = biometrics.get(feature)
        
        # Process fertility indicators
        fertility = user_data.get('fertility_indicators', {})
        
        # Handle categorical features with one-hot encoding
        cervical_fluid = fertility.get('cervical_fluid', 'none')
        features['cervical_fluid_none'] = int(cervical_fluid == 'none')
        features['cervical_fluid_dry'] = int(cervical_fluid == 'dry')
        features['cervical_fluid_sticky'] = int(cervical_fluid == 'sticky')
        features['cervical_fluid_creamy'] = int(cervical_fluid == 'creamy')
        features['cervical_fluid_watery'] = int(cervical_fluid == 'watery')
        features['cervical_fluid_eggwhite'] = int(cervical_fluid == 'eggwhite')
        
        ovulation_test = fertility.get('ovulation_test', 'not_tested')
        features['ovulation_test_negative'] = int(ovulation_test == 'negative')
        features['ovulation_test_positive'] = int(ovulation_test == 'positive')
        features['ovulation_test_not_tested'] = int(ovulation_test == 'not_tested')
        
        # Feature for temperature change
        if 'basal_temp_history' in biometrics and len(biometrics['basal_temp_history']) > 3:
            # Calculate average change in last 3 days
            temp_history = biometrics['basal_temp_history'][-3:]
            features['temp_trend'] = sum(temp_history[i] - temp_history[i-1] for i in range(1, len(temp_history))) / (len(temp_history) - 1)
        else:
            features['temp_trend'] = 0
            
        return features
    
    def prepare_training_data(self, user_cycles: List[Dict], 
                              symptoms_log: List[Dict], 
                              biometrics_log: List[Dict]) -> Tuple[pd.DataFrame, pd.Series, pd.Series, pd.Series]:
        """
        Process historical user data to prepare training datasets for different ML models.
        
        Args:
            user_cycles: List of user cycle data
            symptoms_log: List of symptom logs
            biometrics_log: List of biometric measurements
            
        Returns:
            Tuple of DataFrames for training different models:
            (features_df, cycle_length_series, ovulation_day_series, fertility_window_series)
        """
        # Build complete dataset
        processed_data = []
        
        for cycle in user_cycles:
            cycle_id = cycle.get('id')
            start_date = cycle.get('start_date')
            if isinstance(start_date, str):
                start_date = datetime.fromisoformat(start_date)
                
            end_date = cycle.get('end_date')
            if isinstance(end_date, str):
                end_date = datetime.fromisoformat(end_date)
            
            # Get cycle length
            next_cycle = None
            for next_c in user_cycles:
                next_start = next_c.get('start_date')
                if isinstance(next_start, str):
                    next_start = datetime.fromisoformat(next_start)
                    
                if next_start > start_date:
                    if next_cycle is None or next_start < datetime.fromisoformat(next_cycle.get('start_date')):
                        next_cycle = next_c
            
            if next_cycle:
                next_start = next_cycle.get('start_date')
                if isinstance(next_start, str):
                    next_start = datetime.fromisoformat(next_start)
                    
                cycle_length = (next_start - start_date).days
                cycle_features = {'cycle_id': cycle_id, 'cycle_length': cycle_length}
                
                # Extract recorded ovulation day if available
                ovulation_day = None
                fertility_window_start = None
                fertility_window_end = None
                
                # Find ovulation indicators in this cycle
                for biometric in biometrics_log:
                    log_date = biometric.get('date')
                    if isinstance(log_date, str):
                        log_date = datetime.fromisoformat(log_date)
                        
                    # Check if log belongs to this cycle
                    if start_date <= log_date < next_start:
                        # Look for positive ovulation test or BBT spike
                        if biometric.get('ovulation_test') == 'positive':
                            ovulation_day = (log_date - start_date).days + 1
                            fertility_window_start = max(1, ovulation_day - 5)
                            fertility_window_end = min(cycle_length, ovulation_day + 1)
                            break
                
                # If no ovulation day was detected, use default calculation
                if ovulation_day is None:
                    ovulation_day = round(cycle_length * 0.7)
                    fertility_window_start = max(1, ovulation_day - 5)
                    fertility_window_end = min(cycle_length, ovulation_day + 1)
                
                cycle_features['ovulation_day'] = ovulation_day
                cycle_features['fertility_window_start'] = fertility_window_start
                cycle_features['fertility_window_end'] = fertility_window_end
                
                # Collect symptoms and biometrics for this cycle
                cycle_symptoms = {'symptom_' + s['type']: 1 for s in symptoms_log 
                                 if start_date <= datetime.fromisoformat(s['date']) < next_start}
                
                # Fill missing symptom values with 0
                for symptom in self.binary_symptoms:
                    if f'symptom_{symptom}' not in cycle_symptoms:
                        cycle_symptoms[f'symptom_{symptom}'] = 0
                
                # Process biometric averages for this cycle
                cycle_biometrics = {}
                temp_values = []
                weight_values = []
                
                for biometric in biometrics_log:
                    log_date = biometric.get('date')
                    if isinstance(log_date, str):
                        log_date = datetime.fromisoformat(log_date)
                        
                    # Check if log belongs to this cycle
                    if start_date <= log_date < next_start:
                        if 'basal_temp' in biometric:
                            temp_values.append(biometric['basal_temp'])
                        if 'weight' in biometric:
                            weight_values.append(biometric['weight'])
                
                # Calculate averages if values exist
                if temp_values:
                    cycle_biometrics['basal_temp_avg'] = sum(temp_values) / len(temp_values)
                    cycle_biometrics['basal_temp_max'] = max(temp_values)
                    cycle_biometrics['basal_temp_min'] = min(temp_values)
                    
                if weight_values:
                    cycle_biometrics['weight_avg'] = sum(weight_values) / len(weight_values)
                
                # Add previous cycle length if available
                prev_cycle = None
                for prev_c in user_cycles:
                    prev_start = prev_c.get('start_date')
                    if isinstance(prev_start, str):
                        prev_start = datetime.fromisoformat(prev_start)
                        
                    if prev_start < start_date:
                        if prev_cycle is None or prev_start > datetime.fromisoformat(prev_cycle.get('start_date')):
                            prev_cycle = prev_c
                
                if prev_cycle:
                    prev_start = prev_cycle.get('start_date')
                    if isinstance(prev_start, str):
                        prev_start = datetime.fromisoformat(prev_start)
                        
                    cycle_features['previous_cycle_length'] = (start_date - prev_start).days
                else:
                    cycle_features['previous_cycle_length'] = cycle_length
                
                # Combine all features
                cycle_data = {**cycle_features, **cycle_symptoms, **cycle_biometrics}
                processed_data.append(cycle_data)
        
        # Convert to dataframe
        if not processed_data:
            # Return empty placeholders if no data is available
            empty_df = pd.DataFrame()
            empty_series = pd.Series(dtype=float)
            return empty_df, empty_series, empty_series, empty_series
        
        data_df = pd.DataFrame(processed_data)
        
        # Extract target variables
        cycle_length_series = data_df['cycle_length']
        ovulation_day_series = data_df['ovulation_day']
        fertility_window = data_df[['fertility_window_start', 'fertility_window_end']].copy()
        
        # Drop target variables from features
        features_df = data_df.drop(['cycle_length', 'ovulation_day', 'fertility_window_start', 'fertility_window_end'], axis=1)
        
        # Create combined fertility window series (simplified for this implementation)
        fertility_window_series = fertility_window['fertility_window_end'] - fertility_window['fertility_window_start']
        
        return features_df, cycle_length_series, ovulation_day_series, fertility_window_series
    
    def anonymize_data(self, user_data: List[Dict]) -> List[Dict]:
        """
        Anonymize user data for training global models.
        
        Args:
            user_data: List of user data dictionaries
            
        Returns:
            List of anonymized data dictionaries
        """
        anonymized_data = []
        
        for user_record in user_data:
            # Create a copy without PII
            anon_record = {
                # Replace user ID with a hash
                'user_id_hash': hash(str(user_record.get('user_id'))) % 10000000,
            }
            
            # Copy non-PII fields
            safe_fields = [
                'cycle_lengths', 'avg_cycle_length', 'symptoms', 'biometrics',
                'fertility_indicators', 'cycle_day', 'days_since_last_period'
            ]
            
            for field in safe_fields:
                if field in user_record:
                    anon_record[field] = user_record[field]
            
            # Remove any timestamp information, keep only relative days
            if 'last_period_start' in user_record:
                # Instead of date, just store days since
                if isinstance(user_record['last_period_start'], str):
                    start_date = datetime.fromisoformat(user_record['last_period_start'])
                else:
                    start_date = user_record['last_period_start']
                    
                anon_record['days_since_period'] = (datetime.now() - start_date).days
            
            # Add age range instead of exact age
            if 'age' in user_record:
                age = user_record['age']
                if age < 18:
                    anon_record['age_group'] = 'under_18'
                elif age < 25:
                    anon_record['age_group'] = '18-24'
                elif age < 35:
                    anon_record['age_group'] = '25-34'
                elif age < 45:
                    anon_record['age_group'] = '35-44'
                else:
                    anon_record['age_group'] = '45_plus'
                    
            anonymized_data.append(anon_record)
            
        return anonymized_data
    
    def handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Impute missing values in the dataset.
        
        Args:
            df: DataFrame with potentially missing values
            
        Returns:
            DataFrame with imputed values
        """
        # Make a copy to avoid modifying the original
        result = df.copy()
        
        # Fill missing values for different feature types
        if len(result) > 0:
            # Numeric features - fill with mean
            numeric_cols = ['basal_temp_avg', 'weight_avg', 'basal_temp_max', 'basal_temp_min', 
                           'previous_cycle_length']
            for col in [c for c in numeric_cols if c in result.columns]:
                result[col].fillna(result[col].mean() if not result[col].isna().all() else 0, inplace=True)
                
            # Binary features - fill with 0 (absence)
            binary_cols = [col for col in result.columns if col.startswith('symptom_')]
            for col in binary_cols:
                result[col].fillna(0, inplace=True)
        
        return result
    
    def normalize_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Normalize numeric features to a standard scale.
        
        Args:
            df: DataFrame with features to normalize
            
        Returns:
            DataFrame with normalized features
        """
        # Make a copy to avoid modifying the original
        result = df.copy()
        
        if len(result) > 0:
            # Identify numeric columns to normalize
            numeric_cols = ['basal_temp_avg', 'basal_temp_max', 'basal_temp_min', 
                          'weight_avg', 'previous_cycle_length']
            
            # Apply min-max scaling to each numeric column that exists in the dataset
            for col in [c for c in numeric_cols if c in result.columns]:
                col_min = result[col].min()
                col_max = result[col].max()
                
                # Avoid division by zero
                if col_max > col_min:
                    result[col] = (result[col] - col_min) / (col_max - col_min)
        
        return result
    
    def detect_outliers(self, df: pd.DataFrame, column: str, threshold: float = 3.0) -> List[int]:
        """
        Detect outliers in a specific column using z-score.
        
        Args:
            df: DataFrame to check
            column: Column name to check for outliers
            threshold: Z-score threshold for outlier detection
            
        Returns:
            List of indices of detected outliers
        """
        if column not in df.columns or len(df) < 2:
            return []
            
        mean = df[column].mean()
        std = df[column].std()
        
        if std == 0:
            return []
            
        z_scores = (df[column] - mean) / std
        outlier_indices = df[abs(z_scores) > threshold].index.tolist()
        
        return outlier_indices