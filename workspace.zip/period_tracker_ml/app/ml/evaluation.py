import numpy as np
import pandas as pd
from typing import Dict, Any, List, Union, Optional
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from datetime import datetime, timedelta
import math
import asyncio

class ModelEvaluator:
    """
    Evaluates model performance using various metrics and testing strategies.
    """
    
    def __init__(self):
        """Initialize the model evaluator."""
        pass
    
    async def evaluate_model(self, model: Any, X: pd.DataFrame, y: Union[pd.Series, np.ndarray]) -> Dict[str, float]:
        """
        Evaluate a trained model using appropriate metrics.
        
        Args:
            model: Trained model to evaluate
            X: Feature data
            y: Target data
            
        Returns:
            Dictionary of evaluation metrics
        """
        # Handle ARIMA models (time series)
        if hasattr(model, 'model_type') and model.model_type == "arima":
            return await self._evaluate_time_series_model(model, y)
        
        # For scikit-learn type models
        if X is None or len(X) < 10:
            return {
                "rmse": None,
                "mae": None,
                "r2": None,
                "sample_size": 0
            }
        
        # Split data for evaluation (use the last 20% as test data)
        split_idx = int(len(X) * 0.8)
        X_train = X.iloc[:split_idx]
        X_test = X.iloc[split_idx:]
        y_train = y.iloc[:split_idx] if hasattr(y, 'iloc') else y[:split_idx]
        y_test = y.iloc[split_idx:] if hasattr(y, 'iloc') else y[split_idx:]
        
        # For very small datasets, use LOOCV (Leave One Out Cross Validation)
        if len(X_test) < 5 and len(X) >= 5:
            return await self._perform_loocv(model, X, y)
        
        # For extremely small datasets, report limited metrics
        if len(X_test) < 3:
            return {
                "rmse": None,
                "mae": None,
                "r2": None,
                "sample_size": len(X),
                "note": "Insufficient data for reliable evaluation"
            }
        
        # Make predictions on test set
        try:
            # Direct prediction through model object if it has predict method
            if hasattr(model.model, 'predict'):
                y_pred = model.model.predict(X_test)
            # For async model prediction interface
            elif hasattr(model, 'predict'):
                # Convert test data to the format expected by the predict method
                test_features = {}
                for i, col_name in enumerate(X_test.columns):
                    test_features[col_name] = X_test.iloc[0, i]  # Just use the first test sample
                
                # Get predictions for each test instance
                predictions = []
                for i in range(len(X_test)):
                    for j, col_name in enumerate(X_test.columns):
                        test_features[col_name] = X_test.iloc[i, j]
                    
                    # Get prediction asynchronously
                    pred_result = await model.predict(test_features)
                    predictions.append(pred_result["prediction"])
                
                y_pred = np.array(predictions)
            else:
                return {
                    "error": "Model has no prediction method",
                    "sample_size": len(X)
                }
                
        except Exception as e:
            return {
                "error": f"Prediction failed: {str(e)}",
                "sample_size": len(X)
            }
        
        # Calculate metrics
        metrics = {}
        metrics["rmse"] = float(math.sqrt(mean_squared_error(y_test, y_pred)))
        metrics["mae"] = float(mean_absolute_error(y_test, y_pred))
        metrics["r2"] = float(r2_score(y_test, y_pred)) if len(y_test) > 2 else None
        metrics["sample_size"] = len(X)
        
        # Calculate percentage of predictions within different error thresholds
        abs_errors = np.abs(y_test - y_pred)
        metrics["within_1_day"] = float(np.mean(abs_errors <= 1) * 100)
        metrics["within_2_days"] = float(np.mean(abs_errors <= 2) * 100)
        metrics["within_3_days"] = float(np.mean(abs_errors <= 3) * 100)
        
        return metrics
    
    async def _evaluate_time_series_model(self, model, time_series):
        """
        Evaluate a time series model using specialized metrics.
        
        Args:
            model: ARIMA or other time series model
            time_series: Historical time series data
            
        Returns:
            Dictionary of evaluation metrics
        """
        if not time_series.any():
            return {
                "rmse": None,
                "mae": None,
                "sample_size": 0
            }
        
        # Use the last few points for testing
        n_test = min(3, len(time_series) // 4)
        if n_test < 1:
            n_test = 1
            
        train = time_series[:-n_test]
        test = time_series[-n_test:]
        
        # Train a model on the training data
        try:
            # Create a new model instance for evaluation
            from statsmodels.tsa.arima.model import ARIMA
            model_eval = ARIMA(train, order=model.order).fit()
            
            # Make forecasts
            forecasts = model_eval.forecast(steps=n_test)
            
            # Calculate metrics
            rmse = math.sqrt(mean_squared_error(test, forecasts))
            mae = mean_absolute_error(test, forecasts)
            
            # Calculate percentage of predictions within different error thresholds
            abs_errors = np.abs(test - forecasts)
            within_1_day = np.mean(abs_errors <= 1) * 100
            within_2_days = np.mean(abs_errors <= 2) * 100
            within_3_days = np.mean(abs_errors <= 3) * 100
            
            return {
                "rmse": float(rmse),
                "mae": float(mae),
                "sample_size": len(time_series),
                "within_1_day": float(within_1_day),
                "within_2_days": float(within_2_days),
                "within_3_days": float(within_3_days)
            }
        except Exception as e:
            return {
                "error": f"ARIMA evaluation failed: {str(e)}",
                "sample_size": len(time_series)
            }
    
    async def _perform_loocv(self, model, X, y):
        """
        Perform Leave-One-Out Cross-Validation for small datasets.
        
        Args:
            model: Model to evaluate
            X: Feature data
            y: Target data
            
        Returns:
            Dictionary of evaluation metrics
        """
        n = len(X)
        predictions = []
        actual = []
        
        # For each sample, train on all other samples and test on the left-out sample
        for i in range(n):
            X_train = pd.concat([X.iloc[:i], X.iloc[i+1:]])
            y_train = pd.concat([y.iloc[:i], y.iloc[i+1:]]) if hasattr(y, 'iloc') else np.concatenate([y[:i], y[i+1:]])
            X_test = X.iloc[[i]]
            y_test = y.iloc[i] if hasattr(y, 'iloc') else y[i]
            
            # Train a new model instance
            if hasattr(model, 'model_type') and model.model_type == "random_forest":
                from sklearn.ensemble import RandomForestRegressor
                m = RandomForestRegressor(
                    n_estimators=100,
                    max_depth=None,
                    min_samples_split=2,
                    min_samples_leaf=1
                )
                m.fit(X_train, y_train)
                pred = m.predict(X_test)[0]
            elif hasattr(model, 'model_type') and model.model_type == "gradient_boosting":
                from sklearn.ensemble import GradientBoostingRegressor
                m = GradientBoostingRegressor(
                    n_estimators=100,
                    learning_rate=0.1,
                    max_depth=3
                )
                m.fit(X_train, y_train)
                pred = m.predict(X_test)[0]
            else:
                # Skip if model type is not recognized
                continue
            
            predictions.append(pred)
            actual.append(y_test)
        
        # Calculate metrics
        if len(predictions) > 0:
            rmse = math.sqrt(mean_squared_error(actual, predictions))
            mae = mean_absolute_error(actual, predictions)
            r2 = r2_score(actual, predictions) if len(actual) > 2 else None
            
            # Calculate percentage of predictions within different error thresholds
            abs_errors = np.abs(np.array(actual) - np.array(predictions))
            within_1_day = np.mean(abs_errors <= 1) * 100
            within_2_days = np.mean(abs_errors <= 2) * 100
            within_3_days = np.mean(abs_errors <= 3) * 100
            
            return {
                "rmse": float(rmse),
                "mae": float(mae),
                "r2": float(r2) if r2 is not None else None,
                "sample_size": n,
                "validation": "LOOCV",
                "within_1_day": float(within_1_day),
                "within_2_days": float(within_2_days),
                "within_3_days": float(within_3_days)
            }
        else:
            return {
                "error": "LOOCV failed - no valid predictions",
                "sample_size": n
            }
    
    async def compare_models(self, models_info: List[Dict]) -> Dict[str, Any]:
        """
        Compare multiple models to choose the best one.
        
        Args:
            models_info: List of model information dictionaries
            
        Returns:
            Dictionary with comparison results and best model
        """
        if not models_info:
            return {"best_model": None, "comparison": []}
        
        # Extract metrics and sort models
        comparison = []
        for info in models_info:
            metrics = info.get("metrics", {})
            
            # Calculate a composite score (lower is better)
            # Prioritize predictions within 2 days if available
            if "within_2_days" in metrics:
                accuracy_score = 100 - metrics.get("within_2_days", 0)
            else:
                # Fall back to RMSE if prediction accuracy not available
                accuracy_score = metrics.get("rmse", float('inf'))
            
            comparison.append({
                "model_id": info.get("model_id"),
                "model_type": info.get("model_type"),
                "metrics": metrics,
                "accuracy_score": accuracy_score,
                "created_at": info.get("created_at")
            })
        
        # Sort by accuracy score (lower is better)
        comparison.sort(key=lambda x: x["accuracy_score"])
        
        # Get best model
        best_model = comparison[0] if comparison else None
        
        return {
            "best_model": best_model,
            "comparison": comparison
        }