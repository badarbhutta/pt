import os
import uuid
import time
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Union, Tuple, Any
from fastapi import BackgroundTasks
from datetime import datetime, timedelta
import json
import joblib
import asyncio
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from statsmodels.tsa.arima.model import ARIMA

from app.ml.models import ARIMAModel, RandomForestModel, GradientBoostingModel
from app.ml.preprocessing import DataProcessor
from app.ml.evaluation import ModelEvaluator
from app.schemas.ml import TrainingResponse, ModelInfo, ModelMetrics


class TrainingService:
    """
    Service for managing model training processes including:
    - Triggering training jobs
    - Tracking training status
    - Managing model lifecycle
    """
    
    def __init__(self):
        """Initialize the training service with required components."""
        self.models_directory = "models"
        self.data_processor = DataProcessor()
        self.model_evaluator = ModelEvaluator()
        self.training_jobs = {}  # Store training job status
        
        # Ensure models directory exists
        os.makedirs(self.models_directory, exist_ok=True)

    async def start_training(self, 
                            model_type: str,
                            training_params: Dict = None, 
                            user_id: Optional[int] = None,
                            background_tasks: Optional[BackgroundTasks] = None) -> str:
        """
        Start a training job for a specific model type.
        
        Args:
            model_type: Type of model to train (arima, random_forest, gradient_boosting, ensemble)
            training_params: Parameters for model training
            user_id: Optional user ID for personalized models
            background_tasks: FastAPI BackgroundTasks for async processing
            
        Returns:
            training_id: ID of the started training job
        """
        # Validate model type
        valid_model_types = ["arima", "random_forest", "gradient_boosting", "ensemble"]
        if model_type not in valid_model_types:
            raise ValueError(f"Invalid model type. Must be one of: {', '.join(valid_model_types)}")
        
        # Generate training job ID
        training_id = str(uuid.uuid4())
        
        # Initialize training job status
        self.training_jobs[training_id] = {
            "status": "queued",
            "model_type": model_type,
            "user_id": user_id,
            "params": training_params or {},
            "created_at": datetime.now().isoformat(),
            "completed_at": None,
            "model_id": None,
            "metrics": None,
            "error": None
        }
        
        # Add to background tasks
        if background_tasks:
            background_tasks.add_task(
                self._execute_training_job,
                training_id=training_id,
                model_type=model_type,
                params=training_params or {},
                user_id=user_id
            )
        else:
            # For testing or direct execution
            asyncio.create_task(
                self._execute_training_job(
                    training_id=training_id,
                    model_type=model_type,
                    params=training_params or {},
                    user_id=user_id
                )
            )
        
        return training_id

    async def _execute_training_job(self, training_id: str, model_type: str, params: Dict, user_id: Optional[int] = None):
        """
        Execute a training job in the background.
        
        Args:
            training_id: ID of the training job
            model_type: Type of model to train
            params: Training parameters
            user_id: Optional user ID for personalized models
        """
        try:
            # Update job status
            self.training_jobs[training_id]["status"] = "in_progress"
            
            # Fetch training data
            X, y, additional_data = await self._fetch_training_data(model_type, user_id)
            
            # Create and train model
            model = await self._train_model(model_type, X, y, params, additional_data)
            
            # Evaluate model
            metrics = await self.model_evaluator.evaluate_model(model, X, y)
            
            # Save model
            model_id = f"{model_type}_{str(uuid.uuid4())[:8]}"
            if user_id:
                model_directory = os.path.join(self.models_directory, f"user_{user_id}")
                os.makedirs(model_directory, exist_ok=True)
            else:
                model_directory = self.models_directory
                model_id = f"global_{model_id}"
            
            model.model_id = model_id
            model_path = await model.save(model_directory)
            
            # Update job status
            self.training_jobs[training_id].update({
                "status": "completed",
                "model_id": model_id,
                "completed_at": datetime.now().isoformat(),
                "metrics": metrics,
            })
            
            # Update model registry
            await self._update_model_registry(model_id, model_type, metrics, user_id)
            
        except Exception as e:
            # Handle error
            self.training_jobs[training_id].update({
                "status": "failed",
                "error": str(e),
                "completed_at": datetime.now().isoformat()
            })
            print(f"Training job {training_id} failed: {e}")

    async def _fetch_training_data(self, model_type: str, user_id: Optional[int] = None) -> Tuple[pd.DataFrame, pd.Series, Dict]:
        """
        Fetch and process data for model training.
        
        Args:
            model_type: Type of model to train
            user_id: Optional user ID for personalized data
            
        Returns:
            X: Feature DataFrame
            y: Target Series
            additional_data: Any additional data needed for specific models
        """
        # In production, this would fetch from Laravel API
        # For now, generate synthetic data
        
        # Number of samples for synthetic data
        n_samples = 50
        if user_id:
            # Generate user-specific variation
            variation = hash(str(user_id)) % 5
        else:
            variation = 0
            
        additional_data = {}
            
        if model_type == "arima":
            # For ARIMA, we need time series cycle length data
            cycle_lengths = []
            base_length = 28 + variation
            
            for i in range(n_samples):
                # Generate cycle with some randomness
                cycle = base_length + np.random.randint(-3, 4)
                cycle_lengths.append(cycle)
                
            # ARIMA models work directly on the time series
            return None, np.array(cycle_lengths), {"time_series": cycle_lengths}
            
        elif model_type in ["random_forest", "gradient_boosting"]:
            # Generate feature matrix with symptoms and biometrics
            user_cycles = []
            symptoms_log = []
            biometrics_log = []
            
            # Generate synthetic cycle data
            current_date = datetime.now() - timedelta(days=n_samples * 28)
            
            for i in range(n_samples):
                # Generate cycle with some randomness
                cycle_length = 28 + variation + np.random.randint(-3, 4)
                
                # Create cycle record
                cycle_start = current_date
                cycle_end = cycle_start + timedelta(days=5 + np.random.randint(0, 3))
                
                user_cycles.append({
                    "id": i+1,
                    "start_date": cycle_start.isoformat(),
                    "end_date": cycle_end.isoformat(),
                })
                
                # Generate random symptoms for this cycle
                symptoms = ["cramps", "headache", "mood_swings", "fatigue", "bloating", "acne"]
                days_with_symptoms = np.random.randint(1, 7)
                
                for j in range(days_with_symptoms):
                    symptom_day = cycle_start + timedelta(days=np.random.randint(0, 5))
                    symptom_type = np.random.choice(symptoms)
                    
                    symptoms_log.append({
                        "id": len(symptoms_log) + 1,
                        "date": symptom_day.isoformat(),
                        "type": symptom_type
                    })
                
                # Generate biometric data
                for j in range(cycle_length):
                    log_day = cycle_start + timedelta(days=j)
                    
                    # Basal body temperature follows a pattern
                    if j < cycle_length * 0.6:  # Follicular phase
                        temp = 36.4 + (variation * 0.1) + np.random.normal(0, 0.1)
                    elif j < cycle_length * 0.7:  # Ovulation
                        temp = 36.7 + (variation * 0.1) + np.random.normal(0, 0.1)
                    else:  # Luteal phase
                        temp = 36.6 + (variation * 0.1) + np.random.normal(0, 0.1)
                    
                    # Ovulation test data
                    ovulation_test = "negative"
                    if cycle_length * 0.65 <= j <= cycle_length * 0.72:
                        # Around ovulation
                        ovulation_test = "positive" if np.random.random() > 0.3 else "negative"
                    
                    # Cervical fluid data
                    cervical_fluid = "none"
                    if j < cycle_length * 0.2:
                        cervical_fluid = "dry"
                    elif j < cycle_length * 0.5:
                        cervical_fluid = "sticky"
                    elif j < cycle_length * 0.65:
                        cervical_fluid = "creamy" if np.random.random() > 0.4 else "watery"
                    elif j < cycle_length * 0.75:
                        cervical_fluid = "eggwhite" if np.random.random() > 0.3 else "watery"
                    else:
                        cervical_fluid = "sticky" if np.random.random() > 0.5 else "dry"
                    
                    biometrics_log.append({
                        "id": len(biometrics_log) + 1,
                        "date": log_day.isoformat(),
                        "basal_temp": temp,
                        "weight": 65 + variation + np.random.normal(0, 1),
                        "ovulation_test": ovulation_test,
                        "cervical_fluid": cervical_fluid
                    })
                
                # Move to next cycle
                current_date = cycle_start + timedelta(days=cycle_length)
            
            # Process data for ML model training
            features_df, cycle_length_series, ovulation_day_series, fertility_window_series = (
                self.data_processor.prepare_training_data(user_cycles, symptoms_log, biometrics_log)
            )
            
            # Handle missing values and normalize features
            features_df = self.data_processor.handle_missing_values(features_df)
            features_df = self.data_processor.normalize_features(features_df)
            
            # Return appropriate target variable based on model type
            if model_type == "random_forest":
                return features_df, cycle_length_series, {}
            else:  # gradient_boosting
                return features_df, ovulation_day_series, {"fertility_window": fertility_window_series}
        
        else:  # ensemble or unknown type
            raise ValueError(f"Unsupported model type for data fetching: {model_type}")

    async def _train_model(self, model_type: str, X: pd.DataFrame, y: pd.Series, params: Dict, additional_data: Dict) -> Any:
        """
        Create and train an ML model.
        
        Args:
            model_type: Type of model to train
            X: Feature DataFrame
            y: Target Series
            params: Training parameters
            additional_data: Additional data needed for specific models
            
        Returns:
            Trained model instance
        """
        if model_type == "arima":
            # ARIMA model for cycle prediction
            arima_order = params.get("order", (1, 0, 0))
            model = ARIMAModel()
            model.order = arima_order
            
            # Train on the time series
            time_series = additional_data.get("time_series")
            if not time_series:
                raise ValueError("Missing time series data for ARIMA model")
            
            await model.train(time_series)
            return model
            
        elif model_type == "random_forest":
            # Random Forest for cycle length prediction
            rf_params = {
                "n_estimators": params.get("n_estimators", 100),
                "max_depth": params.get("max_depth"),
                "min_samples_split": params.get("min_samples_split", 2),
                "min_samples_leaf": params.get("min_samples_leaf", 1)
            }
            
            model = RandomForestModel()
            model.model = RandomForestRegressor(**rf_params)
            
            if X is None or len(X) == 0:
                raise ValueError("No training data available for Random Forest model")
                
            await model.train(X, y)
            return model
            
        elif model_type == "gradient_boosting":
            # Gradient Boosting for ovulation prediction
            gb_params = {
                "n_estimators": params.get("n_estimators", 100),
                "learning_rate": params.get("learning_rate", 0.1),
                "max_depth": params.get("max_depth", 3)
            }
            
            model = GradientBoostingModel()
            model.model = GradientBoostingRegressor(**gb_params)
            
            if X is None or len(X) == 0:
                raise ValueError("No training data available for Gradient Boosting model")
                
            await model.train(X, y)
            return model
            
        else:
            raise ValueError(f"Unsupported model type: {model_type}")

    async def _update_model_registry(self, model_id: str, model_type: str, metrics: Dict, user_id: Optional[int] = None):
        """
        Update the model registry with information about the new model.
        
        Args:
            model_id: ID of the trained model
            model_type: Type of model
            metrics: Model performance metrics
            user_id: Optional user ID for personalized models
        """
        registry_path = os.path.join(self.models_directory, "registry.json")
        
        # Load existing registry or create new one
        if os.path.exists(registry_path):
            with open(registry_path, "r") as f:
                registry = json.load(f)
        else:
            registry = {"models": []}
            
        # Add new model information
        model_entry = {
            "model_id": model_id,
            "model_type": model_type,
            "user_id": user_id,
            "created_at": datetime.now().isoformat(),
            "metrics": metrics,
            "is_active": False  # Not active by default
        }
        
        registry["models"].append(model_entry)
        
        # Save updated registry
        with open(registry_path, "w") as f:
            json.dump(registry, f, indent=2)

    async def get_training_status(self, training_id: str) -> TrainingResponse:
        """
        Get the status of a training job.
        
        Args:
            training_id: ID of the training job
            
        Returns:
            Status information for the training job
        """
        job = self.training_jobs.get(training_id)
        if not job:
            raise ValueError(f"Training job {training_id} not found")
        
        response = TrainingResponse(
            training_id=training_id,
            status=job["status"],
            message=f"Training job is {job['status']}",
            model_id=job.get("model_id"),
            metrics=job.get("metrics"),
            error=job.get("error")
        )
        
        return response

    async def list_models(self, model_type: Optional[str] = None, user_id: Optional[int] = None, active_only: bool = False) -> List[ModelInfo]:
        """
        List available ML models with optional filtering.
        
        Args:
            model_type: Optional filter by model type
            user_id: Optional filter by user ID
            active_only: Only return active models
            
        Returns:
            List of model information
        """
        registry_path = os.path.join(self.models_directory, "registry.json")
        
        # Check if registry exists
        if not os.path.exists(registry_path):
            return []
        
        # Load registry
        with open(registry_path, "r") as f:
            registry = json.load(f)
        
        # Filter models
        models = registry.get("models", [])
        filtered_models = []
        
        for model in models:
            # Apply filters
            if model_type and model["model_type"] != model_type:
                continue
                
            if user_id is not None and model["user_id"] != user_id:
                continue
                
            if active_only and not model.get("is_active", False):
                continue
                
            # Convert to ModelInfo
            model_info = ModelInfo(
                model_id=model["model_id"],
                model_type=model["model_type"],
                user_id=model["user_id"],
                created_at=model["created_at"],
                is_active=model.get("is_active", False),
                metrics=model.get("metrics", {})
            )
            
            filtered_models.append(model_info)
        
        return filtered_models

    async def get_model_info(self, model_id: str) -> ModelInfo:
        """
        Get detailed information about a specific model.
        
        Args:
            model_id: ID of the model
            
        Returns:
            Model information
        """
        # Find model in registry
        model_info = await self._find_model_in_registry(model_id)
        if not model_info:
            raise ValueError(f"Model {model_id} not found")
            
        return model_info

    async def get_model_metrics(self, model_id: str) -> ModelMetrics:
        """
        Get performance metrics for a specific model.
        
        Args:
            model_id: ID of the model
            
        Returns:
            Model metrics
        """
        # Find model in registry
        model_info = await self._find_model_in_registry(model_id)
        if not model_info:
            raise ValueError(f"Model {model_id} not found")
            
        metrics = model_info.metrics or {}
        
        return ModelMetrics(
            model_id=model_id,
            rmse=metrics.get("rmse"),
            mae=metrics.get("mae"),
            r2=metrics.get("r2"),
            accuracy=metrics.get("accuracy")
        )

    async def activate_model(self, model_id: str):
        """
        Activate a specific model for predictions.
        
        Args:
            model_id: ID of the model to activate
        """
        registry_path = os.path.join(self.models_directory, "registry.json")
        
        # Check if registry exists
        if not os.path.exists(registry_path):
            raise ValueError("Model registry not found")
        
        # Load registry
        with open(registry_path, "r") as f:
            registry = json.load(f)
        
        # Find model and get its type
        models = registry.get("models", [])
        target_model = None
        user_id = None
        
        for model in models:
            if model["model_id"] == model_id:
                target_model = model
                user_id = model.get("user_id")
                break
                
        if not target_model:
            raise ValueError(f"Model {model_id} not found")
            
        # Deactivate all models of the same type and user
        for model in models:
            if (model["model_type"] == target_model["model_type"] and 
                model.get("user_id") == user_id):
                model["is_active"] = False
        
        # Activate the target model
        target_model["is_active"] = True
        
        # Save updated registry
        with open(registry_path, "w") as f:
            json.dump(registry, f, indent=2)

    async def get_feature_importance(self, model_id: str) -> Dict[str, float]:
        """
        Get feature importance for a specific model.
        
        Args:
            model_id: ID of the model
            
        Returns:
            Dictionary mapping feature names to importance scores
        """
        # Determine model location
        if model_id.startswith("global_"):
            model_directory = self.models_directory
        else:
            # Extract user ID from registry
            model_info = await self._find_model_in_registry(model_id)
            if not model_info or not model_info.user_id:
                raise ValueError(f"Model {model_id} not found or no user ID associated")
                
            model_directory = os.path.join(self.models_directory, f"user_{model_info.user_id}")
        
        # Check if model exists
        model_path = os.path.join(model_directory, f"{model_id}.joblib")
        metadata_path = os.path.join(model_directory, f"{model_id}_metadata.json")
        
        if not os.path.exists(model_path) or not os.path.exists(metadata_path):
            raise ValueError(f"Model files not found for {model_id}")
            
        # Load metadata
        with open(metadata_path, "r") as f:
            metadata = json.load(f)
            
        # Load model
        model_type = metadata["model_type"]
        
        if model_type not in ["random_forest", "gradient_boosting"]:
            raise ValueError(f"Feature importance not available for model type: {model_type}")
            
        # Load the model
        model = joblib.load(model_path)
        features = metadata.get("features", [])
        
        # Extract feature importance
        if not hasattr(model, "feature_importances_"):
            return {}
            
        importances = model.feature_importances_
        
        # Create feature importance dictionary
        if len(features) != len(importances):
            # Use generic feature names if features list is missing or incorrect
            features = [f"feature_{i}" for i in range(len(importances))]
            
        feature_importance = dict(zip(features, importances.tolist()))
        
        # Sort by importance (descending)
        feature_importance = dict(sorted(feature_importance.items(), key=lambda x: x[1], reverse=True))
        
        return feature_importance

    async def _find_model_in_registry(self, model_id: str) -> Optional[ModelInfo]:
        """
        Find a model in the registry by ID.
        
        Args:
            model_id: ID of the model
            
        Returns:
            Model information or None if not found
        """
        registry_path = os.path.join(self.models_directory, "registry.json")
        
        # Check if registry exists
        if not os.path.exists(registry_path):
            return None
        
        # Load registry
        with open(registry_path, "r") as f:
            registry = json.load(f)
        
        # Find model
        for model in registry.get("models", []):
            if model["model_id"] == model_id:
                return ModelInfo(
                    model_id=model["model_id"],
                    model_type=model["model_type"],
                    user_id=model.get("user_id"),
                    created_at=model["created_at"],
                    is_active=model.get("is_active", False),
                    metrics=model.get("metrics", {})
                )
                
        return None