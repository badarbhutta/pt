from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Path, Query
from typing import Dict, List, Optional, Any
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.schemas.ml import (
    TrainingRequest,
    TrainingResponse,
    ModelInfo,
    ModelMetrics,
    ModelsList
)
from app.ml.training import TrainingService
from app import training_service

router = APIRouter()

@router.get("/", response_model=Dict[str, str])
async def get_training_info():
    """Information about the training endpoints."""
    return {
        "status": "active",
        "available_endpoints": [
            "/training/trigger",
            "/training/status/{training_id}",
            "/training/models",
            "/training/models/{model_id}",
            "/training/models/{model_id}/metrics",
            "/training/models/{model_id}/activate",
            "/training/feature-importance/{model_id}"
        ],
        "description": "ML model training and management endpoints"
    }

@router.post("/trigger", response_model=TrainingResponse)
async def trigger_training(
    request: TrainingRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Trigger the training of a new ML model.
    
    - **model_type**: Type of model to train (arima, random_forest, gradient_boosting, ensemble)
    - **training_parameters**: Optional model-specific training parameters
    - **user_id**: Optional user ID for personalized models
    """
    try:
        training_id = await training_service.start_training(
            model_type=request.model_type,
            training_params=request.training_parameters,
            user_id=request.user_id,
            background_tasks=background_tasks
        )
        
        return await training_service.get_training_status(training_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to start training: {str(e)}")

@router.get("/status/{training_id}", response_model=TrainingResponse)
async def get_training_status(
    training_id: str = Path(..., description="ID of the training job"),
    db: Session = Depends(get_db)
):
    """
    Get the status of a training job.
    
    - **training_id**: ID of the training job
    """
    try:
        return await training_service.get_training_status(training_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get training status: {str(e)}")

@router.get("/models", response_model=List[ModelInfo])
async def list_models(
    model_type: Optional[str] = Query(None, description="Optional filter by model type"),
    user_id: Optional[int] = Query(None, description="Optional filter by user ID"),
    active_only: bool = Query(False, description="Only return active models"),
    db: Session = Depends(get_db)
):
    """
    List available ML models with optional filtering.
    
    - **model_type**: Optional filter by model type
    - **user_id**: Optional filter by user ID
    - **active_only**: Only return active models
    """
    try:
        return await training_service.list_models(
            model_type=model_type,
            user_id=user_id,
            active_only=active_only
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list models: {str(e)}")

@router.get("/models/{model_id}", response_model=ModelInfo)
async def get_model_info(
    model_id: str = Path(..., description="ID of the model"),
    db: Session = Depends(get_db)
):
    """
    Get detailed information about a specific model.
    
    - **model_id**: ID of the model
    """
    try:
        return await training_service.get_model_info(model_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get model info: {str(e)}")

@router.get("/models/{model_id}/metrics", response_model=ModelMetrics)
async def get_model_metrics(
    model_id: str = Path(..., description="ID of the model"),
    db: Session = Depends(get_db)
):
    """
    Get performance metrics for a specific model.
    
    - **model_id**: ID of the model
    """
    try:
        return await training_service.get_model_metrics(model_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get model metrics: {str(e)}")

@router.post("/models/{model_id}/activate", response_model=Dict[str, str])
async def activate_model(
    model_id: str = Path(..., description="ID of the model to activate"),
    db: Session = Depends(get_db)
):
    """
    Activate a specific model for predictions.
    
    - **model_id**: ID of the model to activate
    """
    try:
        await training_service.activate_model(model_id)
        
        return {
            "status": "success",
            "message": f"Model {model_id} activated successfully"
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to activate model: {str(e)}")

@router.get("/feature-importance/{model_id}", response_model=Dict[str, float])
async def get_feature_importance(
    model_id: str = Path(..., description="ID of the model"),
    db: Session = Depends(get_db)
):
    """
    Get feature importance for a specific model.
    
    - **model_id**: ID of the model
    """
    try:
        return await training_service.get_feature_importance(model_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get feature importance: {str(e)}")