from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Query
from fastapi.responses import JSONResponse
from typing import Dict, List, Optional, Any
from sqlalchemy.orm import Session
from datetime import datetime, date, timedelta
import json

from app.db.session import get_db
from app.schemas.prediction import (
    PeriodPrediction, 
    FertilityPrediction, 
    OvulationPrediction,
    PredictionFeedback,
    PredictionConfidence,
    PredictionHistory
)
from app.ml.models import PredictionService
from app import prediction_service

router = APIRouter()

@router.get("/", response_model=Dict[str, str])
async def get_predictions_info():
    """Information about the predictions endpoints."""
    return {
        "status": "active",
        "available_endpoints": [
            "/predictions/period",
            "/predictions/fertility",
            "/predictions/ovulation",
            "/predictions/confidence",
            "/predictions/history",
            "/predictions/accuracy"
        ],
        "description": "ML prediction endpoints for menstrual cycle analysis"
    }

@router.post("/period", response_model=PeriodPrediction)
async def predict_period(
    user_id: int,
    days_since_last_period: Optional[int] = None,
    include_model_contributions: bool = False,
    db: Session = Depends(get_db)
):
    """
    Predict the next period start date and cycle length.
    
    - **user_id**: User ID for personalized predictions
    - **days_since_last_period**: Optional override for days since last period (if not provided, calculated from database)
    - **include_model_contributions**: Whether to include detailed model contributions in the response
    """
    try:
        # In production, this would fetch user data from the Laravel API
        # For now, we'll use the prediction service with test data
        
        prediction = await prediction_service.predict_next_period(
            user_id=user_id,
            days_since_last_period=days_since_last_period,
            include_model_contributions=include_model_contributions
        )
        
        # Save prediction to database
        # This would be implemented in a real service
        
        return prediction
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate period prediction: {str(e)}")

@router.post("/fertility", response_model=FertilityPrediction)
async def predict_fertility(
    user_id: int,
    cycle_day: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """
    Predict the fertility window and ovulation date.
    
    - **user_id**: User ID for personalized predictions
    - **cycle_day**: Optional override for current cycle day (if not provided, calculated from database)
    """
    try:
        prediction = await prediction_service.predict_fertility(
            user_id=user_id,
            cycle_day=cycle_day
        )
        
        # Save prediction to database
        # This would be implemented in a real service
        
        return prediction
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate fertility prediction: {str(e)}")

@router.post("/ovulation", response_model=OvulationPrediction)
async def predict_ovulation(
    user_id: int,
    db: Session = Depends(get_db)
):
    """
    Predict the next ovulation date.
    
    - **user_id**: User ID for personalized predictions
    """
    try:
        prediction = await prediction_service.predict_ovulation(
            user_id=user_id
        )
        
        # Save prediction to database
        # This would be implemented in a real service
        
        return prediction
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate ovulation prediction: {str(e)}")

@router.post("/feedback", response_model=Dict[str, str])
async def submit_prediction_feedback(
    feedback: PredictionFeedback,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Submit feedback on a prediction's accuracy for continuous learning.
    
    - **feedback**: Feedback data including the prediction ID and actual outcome
    """
    try:
        # Store feedback
        # This would actually save to the database in production
        
        # Add background task to update model with feedback
        background_tasks.add_task(
            prediction_service.process_feedback,
            feedback=feedback
        )
        
        return {"status": "success", "message": "Feedback received and will be incorporated in future predictions"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to process feedback: {str(e)}")

@router.get("/confidence", response_model=PredictionConfidence)
async def get_prediction_confidence(
    user_id: int,
    prediction_type: str = Query(..., enum=["period", "fertility", "ovulation"]),
    db: Session = Depends(get_db)
):
    """
    Get the confidence score for predictions for a specific user.
    
    - **user_id**: User ID
    - **prediction_type**: Type of prediction (period, fertility, ovulation)
    """
    try:
        confidence = await prediction_service.get_prediction_confidence(
            user_id=user_id,
            prediction_type=prediction_type
        )
        
        return confidence
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve confidence information: {str(e)}")

@router.get("/history", response_model=List[PredictionHistory])
async def get_prediction_history(
    user_id: int,
    prediction_type: Optional[str] = Query(None, enum=["period", "fertility", "ovulation"]),
    limit: int = 10,
    db: Session = Depends(get_db)
):
    """
    Get historical predictions for a user.
    
    - **user_id**: User ID
    - **prediction_type**: Optional filter by prediction type
    - **limit**: Maximum number of records to return
    """
    try:
        # In production, fetch from database
        # For now, return test data
        
        # Create a dummy history for demonstration
        history = []
        
        # Pretend to generate some history
        now = datetime.now()
        
        for i in range(limit):
            history_date = now - timedelta(days=30 * i)
            prediction_date = history_date - timedelta(days=15)
            
            history.append(PredictionHistory(
                id=i+1,
                user_id=user_id,
                prediction_type=prediction_type or "period",
                predicted_date=prediction_date.isoformat(),
                actual_date=history_date.isoformat(),
                accuracy_days=(history_date - prediction_date).days,
                created_at=(prediction_date - timedelta(days=10)).isoformat()
            ))
        
        return history
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve prediction history: {str(e)}")

@router.get("/accuracy", response_model=Dict[str, Any])
async def get_prediction_accuracy(
    user_id: int,
    db: Session = Depends(get_db)
):
    """
    Get accuracy statistics for all prediction types for a user.
    
    - **user_id**: User ID
    """
    try:
        # In production, this would analyze predictions vs. actual data
        # For now, return test data
        
        return {
            "user_id": user_id,
            "overall_accuracy": 87.5,
            "metrics": {
                "period": {
                    "mean_error_days": 1.2,
                    "accuracy_within_1_day": 0.65,
                    "accuracy_within_2_days": 0.85,
                    "predictions_count": 12
                },
                "fertility": {
                    "mean_error_days": 0.9,
                    "accuracy_within_1_day": 0.75,
                    "accuracy_within_2_days": 0.92,
                    "predictions_count": 10
                },
                "ovulation": {
                    "mean_error_days": 1.1,
                    "accuracy_within_1_day": 0.70,
                    "accuracy_within_2_days": 0.88,
                    "predictions_count": 10
                }
            },
            "last_updated": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve accuracy statistics: {str(e)}")