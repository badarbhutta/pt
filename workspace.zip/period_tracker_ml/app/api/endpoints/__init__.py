# API endpoints module initialization
