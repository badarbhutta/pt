"""
Period Tracker ML API initialization.
"""
__version__ = "0.1.0"

# Import ML models and services
from app.ml.models import PredictionService
from app.ml.training import TrainingService
from app.ml.preprocessing import DataProcessor
from app.ml.evaluation import ModelEvaluator

# Initialize ML models directory
import os
os.makedirs("models", exist_ok=True)

# Set up database and services if configured to do so on import
from app.db.session import init_db

# Initialize global services 
prediction_service = PredictionService()
training_service = TrainingService()