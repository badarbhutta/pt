from sqlalchemy import Column, Integer, String, Date, DateTime, Float, ForeignKey, Boolean, JSON
from sqlalchemy.orm import relationship
from datetime import datetime, date
from typing import Dict, Any, List

from app.db.base_class import Base

class Cycle(Base):
    """
    Model for menstrual cycle tracking data.
    Represents a complete menstrual cycle from one period start to the next.
    """
    __tablename__ = "cycles"
    
    # Override default id column from Base
    id = Column(Integer, primary_key=True, index=True)
    
    # User relationship
    user_id = Column(Integer, index=True, nullable=False)
    
    # Cycle dates
    start_date = Column(Date, nullable=False, index=True)
    end_date = Column(Date, nullable=True)  # Can be null if period end not recorded
    
    # Calculated fields
    cycle_length = Column(Integer, nullable=True)  # Calculated when next cycle starts
    period_length = Column(Integer, nullable=True)  # Days from start to end
    
    # Ovulation data (if detected/tracked)
    ovulation_date = Column(Date, nullable=True)
    ovulation_detected = Column(Boolean, default=False)
    ovulation_detection_method = Column(String, nullable=True)  # e.g. "bbt", "test", "symptoms"
    
    # Metadata and flags
    is_complete = Column(Boolean, default=False)  # True when next cycle starts
    is_anomaly = Column(Boolean, default=False)  # Flagged if unusual
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    symptoms = relationship("CycleSymptom", back_populates="cycle", cascade="all, delete-orphan")
    moods = relationship("CycleMood", back_populates="cycle", cascade="all, delete-orphan")
    metrics = relationship("CycleMetric", back_populates="cycle", cascade="all, delete-orphan")
    notes = relationship("CycleNote", back_populates="cycle", cascade="all, delete-orphan")
    predictions = relationship("Prediction", back_populates="cycle")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary for API responses and ML processing"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "cycle_length": self.cycle_length,
            "period_length": self.period_length,
            "ovulation_date": self.ovulation_date.isoformat() if self.ovulation_date else None,
            "ovulation_detected": self.ovulation_detected,
            "ovulation_detection_method": self.ovulation_detection_method,
            "is_complete": self.is_complete,
            "is_anomaly": self.is_anomaly,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Cycle":
        """Create model instance from dictionary data"""
        cycle = cls()
        
        for key, value in data.items():
            if key in ["start_date", "end_date", "ovulation_date"] and value:
                if isinstance(value, str):
                    value = date.fromisoformat(value)
            
            if hasattr(cycle, key):
                setattr(cycle, key, value)
                
        return cycle