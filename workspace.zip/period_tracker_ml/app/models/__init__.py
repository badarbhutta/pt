"""
Models package initialization.
Import all models here to ensure SQLAlchemy can discover them.
"""

# Import all models to ensure they are registered with SQLAlchemy
from app.models.cycle import Cycle
from app.models.prediction import Prediction
from app.models.feedback import PredictionFeedback

# Import any additional models here