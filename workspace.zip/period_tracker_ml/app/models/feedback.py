from sqlalchemy import Column, Integer, String, Date, DateTime, Float, ForeignKey, Boolean, JSON, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from typing import Dict, Any, List

from app.db.base_class import Base

class PredictionFeedback(Base):
    """
    Model for storing user feedback on prediction accuracy.
    This data is used to improve future predictions and evaluate model performance.
    """
    __tablename__ = "prediction_feedback"
    
    # Override default id column from Base
    id = Column(Integer, primary_key=True, index=True)
    
    # Prediction relationship
    prediction_id = Column(Integer, ForeignKey("predictions.id"), unique=True, nullable=False)
    prediction = relationship("Prediction", back_populates="feedback")
    
    # User relationship
    user_id = Column(Integer, nullable=False, index=True)
    
    # Feedback data
    accuracy_rating = Column(Integer, nullable=True)  # User rating (1-5 stars)
    difference_days = Column(Integer, nullable=True)  # Difference in days
    symptoms = Column(JSON, nullable=True)  # List of symptoms experienced
    
    # User notes
    notes = Column(Text, nullable=True)
    
    # Was this feedback used for model retraining?
    used_in_training = Column(Boolean, default=False)
    training_job_id = Column(String, nullable=True)  # ID of training job that used this
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary for API responses"""
        return {
            "id": self.id,
            "prediction_id": self.prediction_id,
            "user_id": self.user_id,
            "accuracy_rating": self.accuracy_rating,
            "difference_days": self.difference_days,
            "symptoms": self.symptoms,
            "notes": self.notes,
            "used_in_training": self.used_in_training,
            "training_job_id": self.training_job_id,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PredictionFeedback":
        """Create model instance from dictionary data"""
        feedback = cls()
        
        for key, value in data.items():
            if hasattr(feedback, key):
                setattr(feedback, key, value)
                
        return feedback