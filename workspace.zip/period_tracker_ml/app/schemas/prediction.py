from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
from datetime import date, datetime

class CycleData(BaseModel):
    """
    Model for user's menstrual cycle history data.
    """
    period_start_dates: List[date] = Field(..., description="List of period start dates")
    period_end_dates: List[date] = Field(..., description="List of period end dates")
    cycle_lengths: List[int] = Field(None, description="Calculated cycle lengths in days")
    period_lengths: List[int] = Field(None, description="Calculated period lengths in days")

class SymptomData(BaseModel):
    """
    Model for user's reported symptoms.
    """
    dates: List[date] = Field(..., description="Dates when symptoms were recorded")
    cramps: List[Optional[int]] = Field(None, description="Cramp severity on scale 0-4")
    mood: List[Optional[str]] = Field(None, description="Mood records")
    headache: List[Optional[int]] = Field(None, description="Headache severity on scale 0-4")
    acne: List[Optional[int]] = Field(None, description="Acne severity on scale 0-4")
    tender_breasts: List[Optional[int]] = Field(None, description="Breast tenderness on scale 0-4")
    bloating: List[Optional[int]] = Field(None, description="Bloating severity on scale 0-4")
    fatigue: List[Optional[int]] = Field(None, description="Fatigue level on scale 0-4")
    custom_symptoms: Optional[Dict[str, List[Any]]] = Field(None, description="Custom symptoms tracked by user")

class LifestyleFactors(BaseModel):
    """
    Model for user's lifestyle data that may affect cycle prediction.
    """
    dates: List[date] = Field(..., description="Dates when lifestyle factors were recorded")
    sleep_quality: List[Optional[int]] = Field(None, description="Sleep quality on scale 0-4")
    stress_level: List[Optional[int]] = Field(None, description="Stress level on scale 0-4")
    exercise_minutes: List[Optional[int]] = Field(None, description="Exercise duration in minutes")
    water_intake_ml: List[Optional[int]] = Field(None, description="Water intake in milliliters")
    weight_kg: List[Optional[float]] = Field(None, description="Weight in kilograms")
    custom_factors: Optional[Dict[str, List[Any]]] = Field(None, description="Custom lifestyle factors tracked by user")

class PredictionRequest(BaseModel):
    """
    Request model for cycle predictions.
    """
    cycle_data: CycleData
    symptoms: Optional[SymptomData] = None
    lifestyle_factors: Optional[LifestyleFactors] = None
    prediction_date: Optional[date] = Field(None, description="Date for which to make predictions (defaults to current date)")

class PredictionResponse(BaseModel):
    """
    Response model for cycle predictions.
    """
    predicted_date: date = Field(..., description="Predicted start date of next period")
    confidence: float = Field(..., description="Confidence score of prediction")
    prediction_window: List[date] = Field(..., description="Date range for prediction window")
    fertility_window_start: Optional[date] = Field(None, description="Start date of predicted fertility window")
    fertility_window_end: Optional[date] = Field(None, description="End date of predicted fertility window")
    features_importance: Optional[Dict[str, float]] = Field(None, description="Importance of each feature in making prediction")
    model_version: str = Field(..., description="Version of the model used for prediction")
    timestamp: datetime = Field(default_factory=datetime.now, description="Timestamp of when prediction was made")
