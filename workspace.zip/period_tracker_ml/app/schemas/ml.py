from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Union
from datetime import datetime

class TrainingParameters(BaseModel):
    """Parameters for training a model."""
    n_estimators: Optional[int] = Field(100, description="Number of estimators for ensemble models")
    max_depth: Optional[int] = Field(None, description="Maximum depth of tree-based models")
    learning_rate: Optional[float] = Field(0.1, description="Learning rate for gradient boosting")
    order: Optional[tuple] = Field((1, 0, 0), description="ARIMA order parameters (p, d, q)")
    
    class Config:
        schema_extra = {
            "example": {
                "n_estimators": 100,
                "learning_rate": 0.1,
                "max_depth": 3
            }
        }

class TrainingRequest(BaseModel):
    """Request for starting a model training job."""
    model_type: str = Field(..., description="Type of model: arima, random_forest, gradient_boosting, ensemble")
    training_parameters: Optional[Dict] = Field({}, description="Model-specific training parameters")
    user_id: Optional[int] = Field(None, description="User ID for personalized models (omit for global models)")
    
    class Config:
        schema_extra = {
            "example": {
                "model_type": "gradient_boosting",
                "training_parameters": {
                    "n_estimators": 100,
                    "learning_rate": 0.1,
                    "max_depth": 3
                },
                "user_id": 123
            }
        }

class TrainingResponse(BaseModel):
    """Response from a model training operation."""
    training_id: str = Field(..., description="Unique ID for the training job")
    status: str = Field(..., description="Status: queued, in_progress, completed, failed")
    message: str = Field(..., description="Status message")
    model_id: Optional[str] = Field(None, description="ID of the trained model (once completed)")
    metrics: Optional[Dict] = Field(None, description="Performance metrics (once completed)")
    error: Optional[str] = Field(None, description="Error message (if failed)")
    
    class Config:
        schema_extra = {
            "example": {
                "training_id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "completed",
                "message": "Training has completed successfully",
                "model_id": "gradient_boosting_12345678",
                "metrics": {
                    "rmse": 1.2,
                    "mae": 0.9,
                    "r2": 0.85
                }
            }
        }

class ModelInfo(BaseModel):
    """Information about a trained model."""
    model_id: str = Field(..., description="Unique model ID")
    model_type: str = Field(..., description="Type of model")
    user_id: Optional[int] = Field(None, description="User ID for personalized models")
    created_at: str = Field(..., description="ISO format creation timestamp")
    is_active: bool = Field(False, description="Whether the model is active for predictions")
    metrics: Optional[Dict] = Field({}, description="Model performance metrics")
    
    class Config:
        schema_extra = {
            "example": {
                "model_id": "gradient_boosting_12345678",
                "model_type": "gradient_boosting",
                "user_id": 123,
                "created_at": "2023-03-25T12:34:56.789Z",
                "is_active": True,
                "metrics": {
                    "rmse": 1.2,
                    "mae": 0.9,
                    "r2": 0.85
                }
            }
        }

class ModelMetrics(BaseModel):
    """Performance metrics for a model."""
    model_id: str = Field(..., description="ID of the model")
    rmse: Optional[float] = Field(None, description="Root Mean Square Error")
    mae: Optional[float] = Field(None, description="Mean Absolute Error")
    r2: Optional[float] = Field(None, description="R-squared coefficient")
    accuracy: Optional[float] = Field(None, description="Accuracy (for classification)")
    
    class Config:
        schema_extra = {
            "example": {
                "model_id": "gradient_boosting_12345678",
                "rmse": 1.2,
                "mae": 0.9,
                "r2": 0.85
            }
        }

class ModelsList(BaseModel):
    """List of model information."""
    models: List[ModelInfo] = Field(..., description="List of available models")