from typing import List, Optional, Union, Dict, Any
from pydantic import BaseSettings, validator
import os
from pathlib import Path

class Settings(BaseSettings):
    # API Settings
    API_V1_STR: str = "/api/v1"
    PROJECT_NAME: str = "Period Tracker ML Engine"
    PROJECT_DESCRIPTION: str = "ML Engine for the Period Tracker App"
    VERSION: str = "0.1.0"
    
    # Security
    API_KEY_NAME: str = "X-API-KEY"
    API_KEY: str = os.getenv("API_KEY", "development_api_key")
    API_KEY_REQUIRED: bool = True
    
    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:8000", "http://localhost:3000"]
    
    # Database
    POSTGRES_SERVER: str = os.getenv("POSTGRES_SERVER", "localhost")
    POSTGRES_USER: str = os.getenv("POSTGRES_USER", "postgres")
    POSTGRES_PASSWORD: str = os.getenv("POSTGRES_PASSWORD", "postgres")
    POSTGRES_DB: str = os.getenv("POSTGRES_DB", "period_tracker")
    SQLALCHEMY_DATABASE_URI: Optional[str] = None
    
    @validator("SQLALCHEMY_DATABASE_URI", pre=True)
    def assemble_db_connection(cls, v: Optional[str], values: Dict[str, Any]) -> str:
        if v:
            return v
        return f"postgresql://{values.get('POSTGRES_USER')}:{values.get('POSTGRES_PASSWORD')}@{values.get('POSTGRES_SERVER')}/{values.get('POSTGRES_DB')}"
    
    # ML Settings
    MODEL_PATH: str = os.getenv("MODEL_PATH", str(Path(__file__).parent.parent.parent / "models"))
    MLFLOW_TRACKING_URI: str = os.getenv("MLFLOW_TRACKING_URI", "sqlite:///mlflow.db")
    
    # ML Parameters
    MIN_CYCLES_FOR_TRAINING: int = 3
    MIN_CYCLES_FOR_USER_MODEL: int = 6
    RETRAINING_GLOBAL_SCHEDULE: str = "0 0 * * 0"  # Weekly on Sunday at midnight
    RETRAINING_USER_SCHEDULE: str = "0 0 1 * *"    # Monthly on 1st at midnight
    
    # Performance Thresholds
    MIN_ACCURACY_THRESHOLD: float = 0.85
    MAX_ERROR_DAYS: int = 3
    
    class Config:
        case_sensitive = True
        env_file = ".env"

settings = Settings()
